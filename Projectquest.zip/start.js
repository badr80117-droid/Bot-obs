import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(ROOT, "dist");
const DIST_ENTRY = path.join(DIST, "index.js");

function run(command, args) {
  const result = spawnSync(command, args, {
    cwd: ROOT,
    stdio: "inherit",
    shell: false,
  });

  if (result.error) {
    console.error("[BOOT] Command failed:", result.error);
    process.exit(1);
  }

  if (result.status !== 0) {
    console.error(`[BOOT] Command exited with code ${result.status}.`);
    process.exit(result.status ?? 1);
  }
}

// Always rebuild production. This prevents stale dist files from keeping old
// values such as badge=60s or questsPerChildProcess=5 after source changes.
console.log("[BOOT] Cleaning old dist...");
fs.rmSync(DIST, { recursive: true, force: true });

console.log("[BOOT] Building production files...");
const npm = process.platform === "win32" ? "npm.cmd" : "npm";
run(npm, ["run", "build"]);

if (!fs.existsSync(DIST_ENTRY)) {
  console.error(`[BOOT] Build finished but ${DIST_ENTRY} does not exist.`);
  process.exit(1);
}

console.log("[BOOT] Starting compiled application: dist/index.js");
await import(pathToFileURL(DIST_ENTRY).href);
