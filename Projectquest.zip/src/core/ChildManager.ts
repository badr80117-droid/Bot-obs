import { fork, ChildProcess } from "child_process";
import path from "path";
import fs from "fs";
import questsConfig from "../config/questsConfig.js";
import { findClosestIndexFolder } from "../utils/tools.js";
import { Logger } from "./logger.js";
import { Collection } from "discord.js";
import { ChildMessage } from "../interface/ChildMessage.js";
import { client } from "../index.js";

export class ChildManager {
  private static childProcesses: Collection<
    number,
    { process: ChildProcess; currentTasks: number }
  > = new Collection();

  static async loadChildProcess() {
    const count = questsConfig.childProcessCount;

    for (let i = 0; i < count; i++) {
      this.spawnChild();
    }
  }
  static get maxUsage() {
    return Math.floor(questsConfig.childProcessCount * questsConfig.questsPerChildProcess);
  }
  static get pids() {
    return this.childProcesses.map((c) => c.process.pid);
  }

  private static respawnCooldowns = new Map<number, boolean>();

  private static spawnChild() {
    const rootFolder = findClosestIndexFolder();
    if (!rootFolder) {
      throw new Error("Project root could not be located.");
    }

    const jsChildPath = path.join(rootFolder, "childProcess", "childProcess.js");
    const tsChildPath = path.join(rootFolder, "childProcess", "childProcess.ts");
    const useCompiledChild = fs.existsSync(jsChildPath);
    const childPath = useCompiledChild ? jsChildPath : tsChildPath;

    const child = fork(childPath, [], {
      stdio: ["inherit", "inherit", "inherit", "ipc"],
      execArgv: useCompiledChild
        ? [
            "--max-old-space-size=512",
            "--expose-gc",
          ]
        : [
            "--max-old-space-size=512",
            "--expose-gc",
            "--experimental-specifier-resolution=node",
            "--loader",
            "ts-node/esm",
          ],
    });

    child.on("message", (msg: ChildMessage) => {
      const type = msg?.type;

      if (type === "ready") {
        Logger.info(`Child process ${child.pid} is ready`);
      } else if (type === "process_update") {

        const childInfo = this.childProcesses.get(child.pid);
        if (childInfo) {
          childInfo.currentTasks = msg.count;
        }
        const totalUsage = this.TotalUsage;
        client.updateActivity()
        Logger.info(`Child process ${child.pid} updated task count to ${msg.count}. Total usage: ${totalUsage}`);
      }
    });

    child.on("exit", (code, signal) => {
      Logger.warn(
        `Child process ${child.pid} exited with code ${code}, signal ${signal}`
      );
      this.childProcesses.delete(child.pid);

      // Cooldown before respawning to avoid rapid crash-loop (e.g. OOM)
      const pid = child.pid;
      if (this.respawnCooldowns.get(pid)) return;
      this.respawnCooldowns.set(pid, true);

      const delay = code === 1 ? 5_000 : 1_000; // 5s after OOM/crash, 1s otherwise
      Logger.info(`Respawning child process in ${delay / 1000}s...`);
      setTimeout(() => {
        this.respawnCooldowns.delete(pid);
        this.spawnChild();
      }, delay);
    });

    this.childProcesses.set(child.pid, {
      process: child,
      currentTasks: 0,
    });

    Logger.info(`Child process ${child.pid} started`);
  }

  static getChildren() {
    return this.childProcesses;
  }

  static getAvailableChild(): ChildProcess | null {
    let selected: { process: ChildProcess; currentTasks: number } | null = null;

    for (const child of this.childProcesses.values()) {
      if (!selected || child.currentTasks < selected.currentTasks) {
        selected = child;
      }
    }

    return selected?.process ?? null;
  }
  static getLowestUsageChild():
    | { process: ChildProcess; currentTasks: number }
    | null {
    let selected: { process: ChildProcess; currentTasks: number } | null = null;

    for (const child of this.childProcesses.values()) {
      if (!selected || child.currentTasks < selected.currentTasks) {
        selected = child;
      }
    }

    return selected;
  }
  static get TotalUsage() {
    return this.childProcesses.reduce((c, p) => c + p.currentTasks, 0);
  }


}
