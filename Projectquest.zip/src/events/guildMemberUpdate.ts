import { ClientEvents, GuildMember } from "discord.js";
import { baseDiscordEvent } from "../lib/handler/baseClientEvent.js";
import questsConfig from "../config/questsConfig.js";
import { userSettingsRepo } from "../core/cache.js";

export default class guildMemberUpdateEvent extends baseDiscordEvent {
    public name: keyof ClientEvents = "guildMemberUpdate";
    public once = false;

    async executeEvent(oldMember: GuildMember, newMember: GuildMember): Promise<void> {
        if (newMember.guild.id !== questsConfig.serverId) return;
        if (newMember.user.bot) return;

        const startedBoost = !oldMember.premiumSinceTimestamp && !!newMember.premiumSinceTimestamp;
        const endedBoost = !!oldMember.premiumSinceTimestamp && !newMember.premiumSinceTimestamp;

        if (startedBoost) {
            await newMember.roles.add(questsConfig.autoQuestRole).catch(err => {
                this.logger.warn(`Failed to grant AutoQuest role to booster ${newMember.id}: ${err?.message || err}`);
            });
            await newMember.send("💎 Boost detected! You received the **AutoQuest** role. Open `/setting` in DM to enable automatic quests.").catch(() => null);
        }

        if (endedBoost) {
            if (newMember.roles.cache.has(questsConfig.autoQuestRole)) {
                await newMember.roles.remove(questsConfig.autoQuestRole).catch(err => {
                    this.logger.warn(`Failed to remove AutoQuest role from former booster ${newMember.id}: ${err?.message || err}`);
                });
            }

            const settings = await userSettingsRepo.findOne({ where: { userId: newMember.id } });
            if (settings?.autoQuest) {
                settings.autoQuest = false;
                await userSettingsRepo.save(settings);
                this.client.userSettings.tempSet(newMember.id, settings, this.client.clientMs("30m"));
                await newMember.send("🛑 Your boost ended, so your **AutoQuest** access was disabled automatically.").catch(() => null);
            }
        }
    }
}
