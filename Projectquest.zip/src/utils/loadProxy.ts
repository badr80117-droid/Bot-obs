import fs from "fs";
import path from "path";
import axios from "axios";
import { ProxyAgent } from "proxy-agent";
import { Collection } from "discord.js";
import { Logger } from "../core/logger.js";
import { findProjectRoot } from "./tools.js";
import questsConfigForHealth from "../config/questsConfig.js";
import { generateHeaders } from "./quest/genrateHeaders.js";

export interface ProxyInterface {
    ip: string;
    authentication?: string;
    /** ISO country code, e.g. US / GB / DE. */
    country?: string;
}

function normalizeCountry(value?: string): string | undefined {
    if (!value) return undefined;
    const country = value.trim().toUpperCase();
    return /^[A-Z]{2}$/.test(country) ? country : undefined;
}

/**
 * Accepted formats in proxy.txt:
 *   IP:PORT
 *   IP:PORT:COUNTRY
 *   IP:PORT:USERNAME:PASSWORD
 *   IP:PORT:USERNAME:PASSWORD:COUNTRY
 *
 * Tab/space separated rows from public proxy lists are also supported:
 *   IP PORT COUNTRY
 */
function parseProxyLine(line: string): ProxyInterface | null {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) return null;

    // URL form: http://user:pass@host:port or socks5://...
    try {
        if (/^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)) {
            const url = new URL(trimmed);
            const host = url.hostname;
            const port = url.port;
            if (!host || !port) return null;
            const country = normalizeCountry(url.hash.replace(/^#/, ""));
            const authentication = url.username || url.password
                ? `${decodeURIComponent(url.username)}:${decodeURIComponent(url.password)}`
                : "";
            return { ip: `${host}:${port}`, authentication, ...(country ? { country } : {}) };
        }
    } catch {
        return null;
    }

    // Public-list table row: IP PORT CC ...
    const whitespace = trimmed.split(/\s+/).filter(Boolean);
    if (whitespace.length >= 2 && /^\d{1,3}(?:\.\d{1,3}){3}$/.test(whitespace[0])) {
        const host = whitespace[0];
        const port = whitespace[1];
        if (/^\d+$/.test(port)) {
            const country = normalizeCountry(whitespace[2]);
            return { ip: `${host}:${port}`, authentication: "", ...(country ? { country } : {}) };
        }
    }

    const split = trimmed.split(":");
    if (split.length === 2) {
        const [host, port] = split;
        if (!host || !/^\d+$/.test(port)) return null;
        return { ip: `${host}:${port}`, authentication: "" };
    }
    if (split.length === 3) {
        const [host, port, country] = split;
        if (!host || !/^\d+$/.test(port)) return null;
        return { ip: `${host}:${port}`, authentication: "", ...(normalizeCountry(country) ? { country: normalizeCountry(country) } : {}) };
    }
    if (split.length >= 4) {
        const [host, port, username, password, country] = split;
        if (!host || !/^\d+$/.test(port)) return null;
        const normalizedCountry = normalizeCountry(country);
        return {
            ip: `${host}:${port}`,
            authentication: `${username ?? ""}:${password ?? ""}`,
            ...(normalizedCountry ? { country: normalizedCountry } : {}),
        };
    }

    return null;
}

async function readProxy(collection: Collection<string, ProxyInterface>): Promise<void> {
    try {
        const proxyPath = path.join(findProjectRoot(), "proxy.txt");
        if (!fs.existsSync(proxyPath)) {
            Logger.warn(`Proxy file not found at: ${proxyPath}`);
            return;
        }

        const data = fs.readFileSync(proxyPath, "utf8");
        const lines = data.split(/\r?\n/);
        collection.clear();

        let invalid = 0;
        for (const rawLine of lines) {
            const parsed = parseProxyLine(rawLine);
            if (!parsed) {
                if (rawLine.trim()) {
                    invalid++;
                    Logger.warn(`Bad Proxy line: ${rawLine}`);
                }
                continue;
            }
            // Use normalized ip + auth + country as the stable key.
            const key = `${parsed.ip}|${parsed.authentication ?? ""}|${parsed.country ?? "UNKNOWN"}`;
            collection.set(key, parsed);
        }

        Logger.info(`Loaded ${collection.size} proxies successfully${invalid ? `, skipped ${invalid} invalid lines` : ""}.`);
    } catch (error) {
        Logger.error("Error reading proxy file:", error);
    }
}

export const writeProxy = async (proxies: string): Promise<void> => {
    try {
        const proxyPath = path.join(findProjectRoot(), "proxy.txt");
        fs.writeFileSync(proxyPath, proxies, "utf8");
        Logger.info(`Proxies have been written to ${proxyPath}`);
    } catch (error) {
        Logger.error("Error writing to proxy file:", error);
    }
};

export function getProxyCountries(collection: Collection<string, ProxyInterface>): string[] {
    return [...new Set(
        collection
            .map(proxy => proxy.country?.toUpperCase())
            .filter((country): country is string => Boolean(country))
    )].sort();
}

export function getProxiesByCountry(collection: Collection<string, ProxyInterface>, country: string): ProxyInterface[] {
    const target = country.toUpperCase();
    return collection.filter(proxy => proxy.country?.toUpperCase() === target).map(proxy => proxy);
}

export default readProxy;


let proxyHealthMonitorStarted = false;

function createProxyRequestConfig(proxy: ProxyInterface) {
    const [host, portStr] = proxy.ip.split(":");
    const port = Number.parseInt(portStr, 10);
    const authentication = proxy.authentication?.trim();

    if (!host || !Number.isFinite(port)) return null;

    if (authentication && authentication !== ":") {
        const [username, password = ""] = authentication.split(":");
        return {
            proxy: {
                protocol: "http" as const,
                host,
                port,
                auth: { username, password },
            },
        };
    }

    return {
        proxy: {
            protocol: "http" as const,
            host,
            port,
        },
    };
}

function getHealthToken(): string | null {
    // Use the configured quest/notification account for the authenticated
    // `/quests/@me` health probe. The token is never logged.
    const token = questsConfigForHealth.notification?.token?.trim();
    return token || null;
}

/**
 * Checks proxy transport AND the actual Discord quest endpoint used by the bot.
 *
 * A gateway response alone is not enough: a proxy can successfully connect to
 * `/gateway` while Discord's `/quests/@me` returns HTTP 503 through that proxy.
 * Such a proxy is treated as unhealthy after repeated quest-endpoint failures.
 */
export async function checkAndCleanProxies(
    collection: Collection<string, ProxyInterface>,
): Promise<{ checked: number; removed: number }> {
    const proxyPath = path.join(findProjectRoot(), "proxy.txt");
    const current = [...collection.entries()];
    let removed = 0;
    const countryStats = new Map<string, { total: number; healthy: number; removed: number }>();

    Logger.info(`[ProxyHealth] Checking ${current.length} configured proxies...`);
    Logger.info(`[ProxyHealth] Probing gateway + Discord quest endpoint (/quests/@me)...`);

    const healthToken = getHealthToken();

    const batchSize = 8;
    for (let i = 0; i < current.length; i += batchSize) {
        const batch = current.slice(i, i + batchSize);
        const results = await Promise.all(batch.map(async ([key, proxy]) => {
            try {
                const config = createProxyRequestConfig(proxy);
                if (!config) return { key, proxy, alive: false, reason: "invalid configuration" };

                const gatewayResponse = await axios.get("https://discord.com/api/v9/gateway", {
                    ...config,
                    timeout: 8_000,
                    validateStatus: () => true,
                    headers: {
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "application/json",
                    },
                });

                if (gatewayResponse.status >= 500) {
                    return { key, proxy, alive: false, reason: `gateway HTTP ${gatewayResponse.status}` };
                }

                if (!healthToken) {
                    // Without a configured account token we can still validate transport.
                    return { key, proxy, alive: true, reason: `gateway HTTP ${gatewayResponse.status}` };
                }

                const questConfig = {
                    ...config,
                    timeout: 10_000,
                    validateStatus: () => true,
                    headers: generateHeaders(healthToken),
                };

                // Authenticated user endpoint tells us whether the proxy can
                // actually reach Discord's API. 401/403 still prove transport.
                const meResponse = await axios.get("https://discord.com/api/v9/users/@me", {
                    ...questConfig,
                    timeout: 8_000,
                    validateStatus: () => true,
                });

                if (meResponse.status >= 500) {
                    return {
                        key,
                        proxy,
                        alive: false,
                        reason: `Discord API HTTP ${meResponse.status}`,
                    };
                }

                // /quests/@me is the actual endpoint the bot uses — if it returns
                // 5xx twice in a row the proxy is not usable for our purposes.
                let questResponse = await axios.get("https://discord.com/api/v9/quests/@me", questConfig);
                if (questResponse.status >= 500) {
                    await new Promise(resolve => setTimeout(resolve, 2_000));
                    questResponse = await axios.get("https://discord.com/api/v9/quests/@me", questConfig);
                }

                if (questResponse.status >= 500) {
                    return {
                        key,
                        proxy,
                        alive: false,
                        reason: `reached Discord but /quests/@me returned HTTP ${questResponse.status} twice`,
                    };
                }

                return {
                    key,
                    proxy,
                    alive: true,
                    reason: `gateway HTTP ${gatewayResponse.status}, /users/@me HTTP ${meResponse.status}, quests HTTP ${questResponse.status}`,
                };
            } catch (error: any) {
                return {
                    key,
                    proxy,
                    alive: false,
                    reason: error?.code || error?.message || "request failed",
                };
            }
        }));

        for (const result of results) {
            const country = result.proxy.country?.toUpperCase() ?? "UNKNOWN";
            const stats = countryStats.get(country) ?? { total: 0, healthy: 0, removed: 0 };
            stats.total++;
            if (result.alive) {
                stats.healthy++;
            } else {
                stats.removed++;
                collection.delete(result.key);
                removed++;
                Logger.warn(`[ProxyHealth] Removed unavailable proxy ${result.proxy.ip}${result.proxy.country ? ` (${result.proxy.country})` : ""} — ${result.reason}`);
            }
            countryStats.set(country, stats);
        }
    }

    try {
        const lines = [...collection.values()].map(proxy => {
            const [host, port] = proxy.ip.split(":");
            const auth = proxy.authentication?.trim();
            if (auth && auth !== ":") {
                return `${host}:${port}:${auth}${proxy.country ? `:${proxy.country}` : ""}`;
            }
            return `${host}:${port}${proxy.country ? `:${proxy.country}` : ""}`;
        });
        fs.writeFileSync(proxyPath, lines.length ? `${lines.join("\n")}\n` : "", "utf8");
    } catch (error) {
        Logger.error("[ProxyHealth] Failed to rewrite proxy.txt:", error);
    }

    for (const [country, stats] of [...countryStats.entries()].sort(([a], [b]) => a.localeCompare(b))) {
        Logger.info(`[ProxyHealth] ${country}: ${stats.healthy}/${stats.total} healthy${stats.removed ? `, ${stats.removed} removed` : ""}.`);
    }
    Logger.info(`[ProxyHealth] Finished. Checked ${current.length}, removed ${removed}, remaining ${collection.size}.`);
    return { checked: current.length, removed };
}

/** Starts the automatic two-hour proxy health check. */
export function startProxyHealthMonitor(
    collection: Collection<string, ProxyInterface>,
): void {
    if (proxyHealthMonitorStarted) return;
    proxyHealthMonitorStarted = true;

    // Check once shortly after startup, then every 2 hours.
    Logger.info(`[ProxyHealth] Monitor started. First check in 15 seconds; next checks every 2 hours.`);

    setTimeout(() => {
        Logger.info(`[ProxyHealth] Starting scheduled proxy health check...`);
        void checkAndCleanProxies(collection);
    }, 15_000);

    setInterval(() => {
        Logger.info(`[ProxyHealth] Starting 2-hour proxy health check...`);
        void checkAndCleanProxies(collection);
    }, 2 * 60 * 60 * 1_000);
}
