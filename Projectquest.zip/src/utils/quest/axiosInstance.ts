import axios, {
  AxiosInstance,
  AxiosProxyConfig,
  AxiosRequestConfig,
  InternalAxiosRequestConfig,
  AxiosResponse,
  AxiosError
} from "axios";
import { ProxyAgent } from "proxy-agent";

import { ProxyInterface } from "../loadProxy.js";
import { generateHeaders } from "./genrateHeaders.js";
import questsConfig from "../../config/questsConfig.js";

interface RateLimitInfo {
  remaining: number | null;
  resetAfter: number | null;
  bucket?: string;
  global?: boolean;
}

const bucketMap = new Map<string, RateLimitInfo>();

export const customAxiosWithProxy = (
  token: string,
  useProxy?: ProxyInterface,
): AxiosInstance => {
  const headers = generateHeaders(token);
  const config = {
    baseURL: "https://discord.com/api/v9/",
    headers,
    timeout: 15_000,
  } as AxiosRequestConfig;

  if (useProxy?.ip) {
    const protocol = questsConfig.proxyType === "socks5" ? "socks5" : "http";
    const proxyAuthentication = useProxy.authentication?.trim();

    if (protocol === "socks5") {
      const [host, port] = useProxy.ip.split(":");
      const proxyUrl = `${protocol}://${proxyAuthentication && proxyAuthentication !== ":"
        ? `${proxyAuthentication.split(":")[0]}:${proxyAuthentication.split(":")[1] ?? ""}@`
        : ""}${host}:${port}`;
      const agent = new ProxyAgent({ getProxyForUrl: () => proxyUrl });
      config.proxy = false;
      config.httpAgent = agent as any;
      config.httpsAgent = agent as any;
    } else {
      const [host, portStr] = useProxy.ip.split(":");
      const proxyConfig: AxiosProxyConfig = {
        protocol: "http",
        host,
        port: Number.parseInt(portStr, 10),
      };
      if (proxyAuthentication && proxyAuthentication !== ":") {
        const [username, password = ""] = proxyAuthentication.split(":");
        proxyConfig.auth = { username, password };
      }
      config.proxy = proxyConfig;
    }
  }

  const axiosInstance = axios.create(config);

  axiosInstance.interceptors.request.use(
    async (req: InternalAxiosRequestConfig) => {
      const bucketKey = `${req.method || "GET"}:${req.url}`;
      const info = bucketMap.get(bucketKey);
      if (info && info.remaining !== null && info.remaining <= 0 && info.resetAfter !== null) {
        await new Promise(resolve => setTimeout(resolve, info.resetAfter * 1000));
      }
      return req;
    },
    error => Promise.reject(error)
  );

  axiosInstance.interceptors.response.use(
    (response: AxiosResponse) => {
      const headers = response.headers;
      const bucketKey = `${response.config.method || "GET"}:${response.config.url}`;
      const remaining = headers["x-ratelimit-remaining"] !== undefined
        ? Number.parseInt(headers["x-ratelimit-remaining"], 10) : null;
      const resetAfter = headers["x-ratelimit-reset-after"] !== undefined
        ? Number.parseFloat(headers["x-ratelimit-reset-after"]) : null;
      const bucket = headers["x-ratelimit-bucket"];
      const global = headers["x-ratelimit-global"] === "true";
      bucketMap.set(bucketKey, { remaining, resetAfter, bucket, global });
      return response;
    },
    async (error: AxiosError) => {
      if (error.response?.status === 429) {
        const retryAfter = error.response.headers["retry-after"] !== undefined
          ? Number.parseFloat(String(error.response.headers["retry-after"])) : null;
        if (retryAfter !== null && retryAfter <= 15) {
          await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
          const retryConfig: any = error.config;
          retryConfig.__questRetry = (retryConfig.__questRetry ?? 0) + 1;
          if (retryConfig.__questRetry <= 1) return axiosInstance.request(retryConfig);
        }
      }
      return Promise.reject(error);
    }
  );

  return axiosInstance;
};
