import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonInteraction,
    ButtonStyle,
    ChatInputCommandInteraction,
    GuildMember,
    Message,
    SlashCommandStringOption,
    StringSelectMenuBuilder,
    StringSelectMenuInteraction,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { I18nInstance } from "../../core/i18n.js";
import { User } from "../../lib/quest/User.js";
import questsConfig from "../../config/questsConfig.js";
import {
    cleanToken,
    getIdFromToken,
    getAuthenticatedUserId,
    isValidDiscordToken,
} from "../../utils/quest/tokenUtils.js";
import { EmbedBuilder } from "../../lib/handler/embedBuilder.js";
import { usersCache } from "../../core/cache.js";
import { ChildManager } from "../../core/ChildManager.js";
import { Logger } from "../../core/logger.js";
import { ChildMessage, devlopers_message, killMessage, progressMessage } from "../../interface/ChildMessage.js";
import { ProxyInterface, getProxiesByCountry, getProxyCountries } from "../../utils/loadProxy.js";
import { delay, disableComponents } from "../../utils/tools.js";

const COUNTRY_NAMES: Record<string, string> = {
    US: "United States", GB: "United Kingdom", CA: "Canada", DE: "Germany", FR: "France",
    ES: "Spain", IT: "Italy", NL: "Netherlands", JP: "Japan", KR: "South Korea", SG: "Singapore",
    HK: "Hong Kong", IN: "India", ID: "Indonesia", TH: "Thailand", MY: "Malaysia", VN: "Vietnam",
    AU: "Australia", BR: "Brazil", MX: "Mexico", TR: "Turkey", AE: "United Arab Emirates", SA: "Saudi Arabia",
    EG: "Egypt", MA: "Morocco", IQ: "Iraq", IL: "Israel", RU: "Russia", UA: "Ukraine", PL: "Poland",
    SE: "Sweden", NO: "Norway", FI: "Finland", DK: "Denmark", CH: "Switzerland", AT: "Austria",
};

// A failed public proxy is kept out for a few minutes, then automatically tested again.
const proxyBlockedUntil = new Map<string, number>();

function proxyKey(proxy: ProxyInterface): string {
    return `${proxy.ip}|${proxy.authentication ?? ""}|${proxy.country ?? ""}`;
}

function markProxyFailed(proxy: ProxyInterface, durationMs = 15 * 60_000) {
    proxyBlockedUntil.set(proxyKey(proxy), Date.now() + durationMs);
}

function isProxyUsable(proxy: ProxyInterface) {
    return (proxyBlockedUntil.get(proxyKey(proxy)) ?? 0) <= Date.now();
}

function shuffle<T>(values: T[]): T[] {
    return [...values].sort(() => Math.random() - 0.5);
}

export default class BadgeCommand extends SlashCommand {
    private activePanels = new Map<string, Message>();
    public name = "badge";
    public description = "Quest a badge";

    public options = [
        new SlashCommandStringOption()
            .setMaxLength(90)
            .setMinLength(58)
            .setName("access")
            .setDescription("Your access token")
            .setRequired(true),
    ];

    public cooldown: number | string = 10_000;
    public permissions: permissionList[] = ["Administrator"];
    public bot_permissions: permissionList[] = [];
    public flags: slashCommandFlags[] = ["onlyDm", "noReply"];

    private async safeEdit(msg, payload) {
        return msg?.edit?.(payload).catch(() => null);
    }

    private async safeEditInteraction(interaction: ChatInputCommandInteraction, payload: any) {
        try { return await interaction.editReply(payload); }
        catch (err) { Logger.error(`Failed to edit /badge interaction ${interaction.id}:`, err); return null; }
    }

    private async logAndUpdate(user: User, msg, log: string) {
        user.logs.push(log);
        await this.safeEdit(msg, { ...user.genreate_message() });
    }

    private async getMember(id: string): Promise<GuildMember | null> {
        const guild = this.client.guilds.cache.get(questsConfig.serverId)
            ?? await this.client.guilds.fetch(questsConfig.serverId).catch(() => null);
        return guild?.members?.cache.get(id) ?? await guild?.members.fetch(id).catch(() => null);
    }

    private countryOptions(client: CustomClient) {
        const countries = getProxyCountries(client.proxy);
        return countries.slice(0, 24).map(code => ({
            label: COUNTRY_NAMES[code] ?? code,
            value: code,
            emoji: { name: "🌍" },
        }));
    }

    private buildCountryPicker(client: CustomClient, i18n?: I18nInstance) {
        const menu = new StringSelectMenuBuilder()
            .setCustomId("badge_proxy_country")
            .setPlaceholder(i18n?.t("badge.chooseCountryPlaceholder") ?? "🌍 Choose a country")
            .setMinValues(1)
            .setMaxValues(1);

        menu.addOptions({
            label: "عالمي",
            value: "DIRECT",
            description: i18n?.t("badge.globalFallbackDescription") ?? "If other countries do not work, choose Global.",
            emoji: { name: "🌐" },
        });
        menu.addOptions(this.countryOptions(client));

        return {
            embeds: [new EmbedBuilder()
                .setTitle(i18n?.t("badge.chooseCountryTitle") ?? "🌍 Choose a country")
                .setDescription(i18n?.t("badge.chooseCountryDescription") ?? "Choose the country to use for your quests. If it does not work, try another country or choose Global.")
                .setColor("Blurple")],
            components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu)],
        };
    }

    private async buildUserWithWorkingProxy(
        token: string,
        country: string | null,
        client: CustomClient,
        i18n: I18nInstance,
        target: ChatInputCommandInteraction | ButtonInteraction,
    ): Promise<User | null> {
        const candidates = country && country !== "DIRECT"
            ? shuffle(getProxiesByCountry(client.proxy, country).filter(isProxyUsable))
            : [undefined];

        if (country && country !== "DIRECT" && candidates.length === 0) {
            return null;
        }

        for (const proxy of candidates) {
            const user = new User(token, proxy as any);
            user.setI18n(i18n);
            const ok = await this.tryFetchQuests(user, target, i18n, true);
            if (ok) {
                Logger.info(`Quest fetch succeeded${proxy ? ` via ${proxy.ip} (${proxy.country ?? "unknown"})` : " directly"}.`);
                return user;
            }

            if (proxy) {
                // 5xx repeated twice already means the proxy can't reach /quests/@me —
                // block it for 15 min. Connection/transport errors get the same treatment.
                markProxyFailed(proxy);
            }
            user.destroy();
        }
        return null;
    }

    public async execute({ interaction, client, i18n }: {
        interaction: ChatInputCommandInteraction;
        client: CustomClient;
        i18n: I18nInstance;
        lang: string;
    }): Promise<any> {
        const authorMember = await this.getMember(interaction.user.id);
        const isVip = authorMember?.roles?.cache?.some(e => questsConfig?.bypassLimit?.includes(e.id)) ?? false;
        if (ChildManager.TotalUsage >= ChildManager.maxUsage && !isVip) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.maxUsage", {
                usage: ChildManager.TotalUsage.toString(), maxUsage: ChildManager.maxUsage,
            })).setColor("DarkRed")], ephemeral: false });
        }

        await interaction.deferReply();
        const token = cleanToken(interaction.options.getString("access", true));
        const id = getIdFromToken(token);
        if (!isValidDiscordToken(token) || !id) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.invalidToken"))] });
        }

        const authenticatedId = await getAuthenticatedUserId(token);
        if (!authenticatedId || authenticatedId !== interaction.user.id || id !== interaction.user.id) {
            Logger.warn(`Blocked badge token mismatch: commandUser=${interaction.user.id}, tokenUser=${authenticatedId ?? id ?? "unknown"}`);
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.tokenMismatch")).setColor("DarkRed")] });
        }

        const member = await this.getMember(id);
        if (!member) return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.joinServer")).setColor("DarkRed")] });

        const previousPanel = this.activePanels.get(interaction.user.id);
        if (previousPanel) {
            await previousPanel.edit({ components: disableComponents(previousPanel.components) }).catch(() => null);
            this.activePanels.delete(interaction.user.id);
        }

        const oldQuest = usersCache.get(id);
        if (oldQuest) {
            if (oldQuest.panelMessage) {
                await oldQuest.panelMessage.edit({ components: disableComponents(oldQuest.panelMessage.components) }).catch(() => null);
            }
            // Cancel the active quest immediately. For "Do All", User.stop() also
            // cancels the worker currently executing a quest.
            oldQuest.cancelRequested = true;
            await oldQuest.stop(true);
            Logger.warn(`[Badge] User ${id} opened /badge again; previous panel and active quest stopped.`);
        }

        if (questsConfig.useProxy && getProxyCountries(client.proxy).length > 0) {
            const picker = this.buildCountryPicker(client, i18n);
            await interaction.editReply(picker);
            const msg = await interaction.fetchReply();
            this.activePanels.set(interaction.user.id, msg);
            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === interaction.user.id,
                time: client.clientMs("5m"),
            });

            let regionBusy = false;

            collector.on("collect", async i => {
                if (!i.isStringSelectMenu() || i.customId !== "badge_proxy_country") return;
                if (regionBusy) {
                    await i.deferUpdate().catch(() => null);
                    return;
                }

                const country = i.values[0];
                regionBusy = true;
                Logger.info(`[Badge] ${interaction.user.id} selected region ${country}.`);

                // Acknowledge the component immediately by updating the original message.
                // Do not wait for proxy/quest requests: those can exceed Discord's
                // interaction acknowledgement window and cause "Test didn't respond in time".
                try {
                    await i.update({
                        embeds: [new EmbedBuilder().setDescription(
                            i18n.t("badge.connectingRegion", { region: country === "DIRECT" ? i18n.t("badge.global") : (COUNTRY_NAMES[country] ?? country) })
                        )],
                        components: [],
                    });
                } catch (err) {
                    regionBusy = false;
                    Logger.error(`Failed to acknowledge badge country selection ${i.id}:`, err);
                    return;
                }

                // Continue outside the interaction acknowledgement path. If the chosen
                // country is unavailable, finishBadgeAfterRegion restores the picker so the
                // same collector can accept another country without a fresh /badge command.
                void this.finishBadgeAfterRegion(
                    interaction, i18n, client, member, isVip, token, country
                ).then(user => {
                    regionBusy = false;
                    if (user) collector.stop("completed");
                }).catch(err => {
                    regionBusy = false;
                    Logger.error(`Country selection handling failed:`, err);
                });
            });
            collector.on("end", async (_c, reason) => {
                // Do not disable the quest controls when a working region was selected;
                // setupCollector owns the new quest interaction lifecycle.
                if (reason === "completed") return;
                await msg.edit({ components: disableComponents(msg.components) }).catch(() => null);
                if (this.activePanels.get(interaction.user.id)?.id === msg.id) this.activePanels.delete(interaction.user.id);
            });
            return;
        }

        await this.finishBadgeAfterRegion(interaction, i18n, client, member, isVip, token, "DIRECT");
    }

    private async finishBadgeAfterRegion(
        interaction: ChatInputCommandInteraction,
        i18n: I18nInstance,
        client: CustomClient,
        member: GuildMember,
        isVip: boolean,
        token: string,
        country: string,
    ): Promise<User | null> {
        Logger.info(`[Badge] Fetching quests for ${interaction.user.id} using ${country === "DIRECT" ? "Global/direct" : (COUNTRY_NAMES[country] ?? country)}.`);
        await this.safeEditInteraction(interaction, { embeds: [new EmbedBuilder().setDescription(
            country !== "DIRECT"
                ? i18n.t("badge.fetchingQuestsFromRegion", { region: COUNTRY_NAMES[country] ?? country })
                : i18n.t("badge.fetchingQuests")
        )] });

        const user = await this.buildUserWithWorkingProxy(token, country, client, i18n, interaction);
        if (!user) {
            const label = country === "DIRECT" ? i18n.t("badge.global") : (COUNTRY_NAMES[country] ?? country);
            await this.safeEditInteraction(interaction, {
                embeds: [new EmbedBuilder().setDescription(i18n.t("badge.regionUnavailable", { region: label })).setColor("DarkRed")],
                components: questsConfig.useProxy && getProxyCountries(client.proxy).length ? this.buildCountryPicker(client, i18n).components : [],
            });
            return null;
        }

        if (user.quests.size === 0) {
            user.destroy();
            await this.safeEditInteraction(interaction, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.noQuests"))] });
            return null;
        }

        user.canUseAllQuests = member.roles.cache.has(questsConfig.autoQuestRole);
        (user as any).badgeToken = token;
        user.setQuest(user.quests.first()!);
        await this.safeEditInteraction(interaction, { ...user.genreate_message() });
        const msg = await interaction.fetchReply();
        user.panelMessage = msg;
        this.activePanels.set(interaction.user.id, msg);
        this.setupCollector(interaction.user.id, user, member, msg, client, i18n, isVip);
        return user;
    }

    private async tryFetchQuests(user: User, target: ChatInputCommandInteraction | ButtonInteraction, i18n: I18nInstance, silent = false): Promise<boolean> {
        try {
            for (let attempt = 1; attempt <= 3; attempt++) {
                const quests = await Promise.race([
                    user.fetchQuests(),
                    new Promise<null>(resolve => setTimeout(() => resolve(null), 12_000)),
                ]);
                if (quests && quests.size > 0) return true;

                const status = user.lastQuestFetchStatus;
                if (!(status && status >= 500 && status < 600) || attempt === 3) break;
                Logger.warn(`[Badge] Quest endpoint returned HTTP ${status}; retrying (${attempt + 1}/3).`);
                await delay(1_200 * attempt);
            }

            if (!silent) await this.safeEditInteraction(target as ChatInputCommandInteraction, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.errorFetch")).setColor("DarkRed")], components: [] });
            return false;
        } catch (err) {
            Logger.error(`Failed to fetch quests for user ${user.id}:`, err);
            if (!silent) await this.safeEditInteraction(target as ChatInputCommandInteraction, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.errorFetch")).setColor("DarkRed")], components: [] });
            return false;
        }
    }

    private registerChildHandlers(user: User, member: GuildMember | null, msg, i18n: I18nInstance, collector) {
        const handlers: Record<string, (m: ChildMessage) => Promise<void>> = {
            progress_update: async (m: progressMessage) => {
                const completed = user?.completed === true;
                await user.updateProgress(m?.data?.progress, m.data?.completed);
                await this.logAndUpdate(user, msg, i18n.t("badge.progressUpdate", { progress: m.data.progress, goal: m.data.target }));
                if (m?.data?.completed && !completed) {
                    await this.logAndUpdate(user, msg, i18n.t("badge.questCompleted"));
                    user.completed = true;
                    await user.sendCompleted();
                    user.stop();
                    collector.stop();
                }
            },
            kill: async (m: killMessage) => {
                await this.logAndUpdate(user, msg, `${i18n.t("badge.killed")}: ${m.message || ""}`);
                if (!user.stoped) { await user.stop(); collector.stop(); }
            },
            logged_in: async () => this.logAndUpdate(user, msg, i18n.t("badge.loggedIn")),
            logged_out: async () => { await this.logAndUpdate(user, msg, i18n.t("badge.loggedOut")); if (!user.stoped) { await user.stop(); collector.stop(); } },
            login_error: async () => { await this.logAndUpdate(user, msg, i18n.t("badge.regionLoginError")); if (!user.stoped) { await user.stop(); collector.stop(); } },
            bad_channel: async () => { await this.logAndUpdate(user, msg, i18n.t("badge.badVoiceChannel")); if (!user.stoped) { await user.stop(); collector.stop(); } },
            role_timeout: async () => { await this.logAndUpdate(user, msg, i18n.t("badge.roleTimeout")); if (!user.stoped) { await user.stop(); collector.stop(); } },
            devlopers_message: async (m: devlopers_message) => { if (m?.message) await this.logAndUpdate(user, msg, i18n.t("badge.devMessage", { message: m.message })); },
            connected_to_channel: async () => this.logAndUpdate(user, msg, i18n.t("badge.connectedToChannel")),
            role_required: async () => {
                await this.logAndUpdate(user, msg, i18n.t("badge.roleRequired"));
                if (member && questsConfig?.voice.role) {
                    await member.roles.add(questsConfig.voice.role).catch(() => null);
                    user.send({ type: "role_received", target: user.id });
                    setTimeout(() => member.roles.remove(questsConfig.voice.role!).catch(() => null), 30_000);
                }
            },
        };

        const listener = async (m: ChildMessage) => {
            if ("target" in m && typeof m.target === "string" && m.target !== user.id) return;
            const handler = handlers[m.type];
            if (handler) try { await handler(m); } catch (err) { Logger.error(`Handler error for message type ${m.type}:`, err); }
        };
        user.on("message", listener);
        user.once("stopped", () => user.off("message", listener));
    }

    private async ensureProxyAlive(user: User, client: CustomClient, country: string | null): Promise<boolean> {
        if (!user.proxy) return true;
        const candidates = country && country !== "DIRECT"
            ? shuffle(getProxiesByCountry(client.proxy, country).filter(p => isProxyUsable(p) && proxyKey(p) !== proxyKey(user.proxy!)))
            : [];
        const attempts = [user.proxy, ...candidates];
        for (const proxy of attempts) {
            user.setProxy(proxy);
            try {
                // Check the actual quest endpoint — not just /users/@me.
                // A proxy can reach the users endpoint while failing on /quests/@me.
                const res = await user.api.get("/quests/@me", { timeout: 8_000, validateStatus: () => true });
                if (res.status < 500) return true;
                markProxyFailed(proxy);
            } catch {
                markProxyFailed(proxy);
            }
        }
        return false;
    }

    private async runAllQuests(token: string, panelUser: User, member: GuildMember, client: CustomClient, i18n: I18nInstance, msg: Message, isVip = false) {
        // Snapshot only quests that are not fully completed. Completed quests are
        // never started by the "Do All" button, even when they are still present
        // in the fetched quest list.
        const isQuestCompleted = (q) =>
            q.isCompleted() || (q.progress.length > 0 && q.progress.every(t => t.completed));
        const snapshot = Array.from(panelUser.quests.values())
            .filter(q => !isQuestCompleted(q));
        if (!snapshot.length) {
            panelUser.started = false;
            await this.safeEdit(msg, { ...panelUser.genreate_message() });
            return;
        }

        try {
            for (let index = 0; index < snapshot.length; index++) {
                if (panelUser.cancelRequested || panelUser.destroyed || panelUser.stoped) {
                    Logger.info(`[Badge] Do All cancelled for ${panelUser.id}.`);
                    break;
                }
                const questId = snapshot[index].id;
                await this.safeEdit(msg, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.allQuestsProgress", { current: index + 1, total: snapshot.length, quest: snapshot[index].data.config.messages.quest_name })).setColor("Blurple")] , components: [] });

                const worker = new User(token, panelUser.proxy, false);
                worker.setI18n(i18n);
                panelUser.activeWorker = worker;
                if (panelUser.cancelRequested || panelUser.destroyed || panelUser.stoped) {
                    worker.destroy();
                    panelUser.activeWorker = null;
                    break;
                }
                const quests = await worker.fetchQuests();
                const quest = quests?.get(questId);
                if (!quest) {
                    worker.destroy();
                    continue;
                }
                if (isQuestCompleted(quest)) {
                    worker.destroy();
                    continue;
                }
                if (!quest.isSupported()) {
                    panelUser.logs.push(i18n.t("badge.unsupportedSkipped", { quest: quest.data.config.messages.quest_name }));
                    worker.destroy();
                    continue;
                }
                if (!quest.progress.some(p => p.enrolled) && !(await quest.enroll())) {
                    panelUser.logs.push(i18n.t("badge.enrollFailedForQuest", { quest: quest.data.config.messages.quest_name }));
                    worker.destroy();
                    continue;
                }
                await worker.fetchQuests();
                worker.setQuest(worker.quests.get(questId) ?? quest);
                const child = ChildManager.getLowestUsageChild();
                if (!child?.process || (child.currentTasks >= questsConfig.questsPerChildProcess && !isVip)) {
                    panelUser.logs.push(i18n.t("badge.workerUnavailable"));
                    worker.destroy();
                    break;
                }
                worker.setProcess(child.process);
                child.currentTasks++;

                await new Promise<void>(async resolve => {
                    let done = false;
                    const finish = async (message?: string) => {
                        if (done) return;
                        done = true;
                        if (message) panelUser.logs.push(message);
                        resolve();
                    };
                    const listener = async (m: ChildMessage) => {
                        if ("target" in m && typeof m.target === "string" && m.target !== worker.id) return;
                        if (m.type === "progress_update") {
                            await worker.updateProgress(m.data.progress, m.data.completed);
                            panelUser.logs.push(i18n.t("badge.progressUpdate", { progress: m.data.progress, goal: m.data.target }));
                            await this.safeEdit(msg, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.allQuestsRunning", { current: index + 1, total: snapshot.length, quest: worker.selectedQuest?.data.config.messages.quest_name ?? quest.data.config.messages.quest_name, progress: m.data.progress, goal: m.data.target })).setColor("Blurple")] });
                            if (m.data.completed) {
                                await finish(i18n.t("badge.questCompleted"));
                                await worker.stop();
                            }
                        } else if (m.type === "login_error" || m.type === "ERROR") {
                            await finish(i18n.t("badge.questFailedForQuest", { quest: quest.data.config.messages.quest_name }));
                            if (!worker.stoped) await worker.stop();
                        } else if (m.type === "kill") {
                            await finish(i18n.t("badge.killed"));
                        }
                    };
                    worker.on("message", listener);
                    worker.once("stopped", () => {
                        worker.off("message", listener);
                        if (!done) void finish(i18n.t("badge.killed"));
                        worker.destroy();
                    });
                    try { await worker.start(); } catch { await finish(i18n.t("badge.questFailedForQuest", { quest: quest.data.config.messages.quest_name })); worker.destroy(); }
                });
                panelUser.activeWorker = null;
                if (panelUser.cancelRequested || panelUser.destroyed || panelUser.stoped) break;
            }
        } finally {
            panelUser.activeWorker = null;
            panelUser.started = false;
            panelUser.completed = false;
            panelUser.logs.push(i18n.t("badge.allQuestsDone"));
            await this.safeEdit(msg, { ...panelUser.genreate_message() });
        }
    }

    private setupCollector(author: string, user: User, member: GuildMember, msg: Message, client: CustomClient, i18n: I18nInstance, isVip = false) {
        const collector = msg.createMessageComponentCollector({ filter: i => i.user.id === author, time: client.clientMs("20m") });

        collector.on("collect", async (i: ButtonInteraction | StringSelectMenuInteraction) => {
            try {
                if (i.isStringSelectMenu()) {
                    if (i.customId !== "selectBadge") return;
                    const quest = user.quests.get(i.values[0]);
                    if (quest) user.setQuest(quest);
                    return i.update({ ...user.genreate_message() });
                }
                switch (i.customId) {
                    case "enroll": {
                        const response = await user.selectedQuest.enroll();
                        if (response) return i.update({ ...user.genreate_message() });
                        return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.enrollFailed")).setColor("DarkRed")], ephemeral: true });
                    }
                    case "start": {
                        if (user.started) return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.alreadyStarted")).setColor("DarkRed")], ephemeral: true });
                        const childProcess = ChildManager.getLowestUsageChild();
                        if (!childProcess?.process) return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.workerUnavailable")).setColor("DarkRed")], ephemeral: true });
                        if (childProcess.currentTasks >= questsConfig.questsPerChildProcess && !isVip) return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.maxUsage", { usage: ChildManager.TotalUsage.toString(), maxUsage: ChildManager.maxUsage })).setColor("DarkRed")], ephemeral: true });

                        await i.deferUpdate();
                        const country = user.proxyCountry;
                        if (!(await this.ensureProxyAlive(user, client, country))) {
                            return this.safeEdit(msg, { embeds: [new EmbedBuilder().setDescription(i18n.t("badge.regionUnavailable", { region: country && country !== "DIRECT" ? (COUNTRY_NAMES[country] ?? country) : i18n.t("badge.global") })).setColor("DarkRed")], components: this.buildCountryPicker(client, i18n).components });
                        }

                        user.cancelRequested = false;
                        user.setProcess(childProcess.process);
                        this.registerChildHandlers(user, member, msg, i18n, collector);
                        childProcess.currentTasks++;
                        await user.start();
                        await this.logAndUpdate(user, msg, `${i18n.t("badge.started")} • 🌍 ${user.proxyCountry ? (COUNTRY_NAMES[user.proxyCountry] ?? user.proxyCountry) : i18n.t("badge.global")}`);
                        return this.safeEdit(msg, { ...user.genreate_message() });
                    }
                    case "allQuests": {
                        if (!user.canUseAllQuests) {
                            return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.autoQuestRoleRequired")).setColor("DarkRed")], ephemeral: true });
                        }
                        if (user.started || user.stoped) {
                            return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.alreadyStarted")).setColor("DarkRed")], ephemeral: true });
                        }
                        const childProcess = ChildManager.getLowestUsageChild();
                        if (!childProcess?.process || (childProcess.currentTasks >= questsConfig.questsPerChildProcess && !isVip)) {
                            return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.maxUsage", { usage: ChildManager.TotalUsage.toString(), maxUsage: ChildManager.maxUsage })).setColor("DarkRed")], ephemeral: true });
                        }
                        await i.update({ ...user.genreate_message() }).catch(() => null);
                        user.cancelRequested = false;
                        user.activeWorker = null;
                        user.started = true;
                        await this.safeEdit(msg, { ...user.genreate_message() });
                        void this.runAllQuests((user as any).badgeToken, user, member, client, i18n, msg, isVip)
                            .catch(err => Logger.error(`[Badge] allQuests failed for ${author}:`, err));
                        return;
                    }

                    case "refresh": {
                        if (!(await this.tryFetchQuests(user, i, i18n))) return;
                        return i.update({ ...user.genreate_message() });
                    }
                    case "stop": {
                        if (user.stoped) return i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.alreadyStoped")).setColor("DarkRed")], ephemeral: true });
                        user.stop();
                        collector.stop();
                        return i.update({ ...user.genreate_message() });
                    }
                }
            } catch (err) {
                Logger.error("Collector error:", err);
                await i.reply({ embeds: [new EmbedBuilder().setDescription(i18n.t("badge.genericError")).setColor("DarkRed")], ephemeral: true }).catch(() => null);
            }
        });

        collector.on("end", async () => {
            await delay(500);
            await msg.edit({ components: disableComponents(msg.components) }).catch(() => null);
            if (this.activePanels.get(author)?.id === msg.id) this.activePanels.delete(author);
            if (!user.destroyed) user.destroy();
        });
    }
}
