import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonInteraction,
    ButtonStyle,
    ChatInputCommandInteraction,
    EmbedBuilder,
    GuildMember,
    SlashCommandStringOption,
} from "discord.js";
import { SlashCommand, slashCommandFlags } from "../../lib/handler/slashCommand.js";
import { CustomClient } from "../../core/customClient.js";
import { permissionList } from "../../lib/handler/messageCommand.js";
import { I18nInstance } from "../../core/i18n.js";
import { userSettingsRepo } from "../../core/cache.js";
import questsConfig from "../../config/questsConfig.js";
import {
    cleanToken,
    getIdFromToken,
    getAuthenticatedUserId,
    isValidDiscordToken,
} from "../../utils/quest/tokenUtils.js";

export default class SettingCommand extends SlashCommand {
    public name = "setting";
    public description = "Manage your auto-quest settings";

    public options = [
        new SlashCommandStringOption()
            .setMaxLength(90)
            .setMinLength(58)
            .setName("access")
            .setDescription("Your Discord access token (provide to save/update it)")
            .setRequired(false),
    ];

    public cooldown: number | string = "10s";
    public permissions: permissionList[] = [];
    public bot_permissions: permissionList[] = [];
    public flags: slashCommandFlags[] = ["ephemeral", "onlyDm"];

    private AUTO_QUEST_ROLE = questsConfig.autoQuestRole;

    /** Check if the user has the required role in the main server */
    private async getMember(userId: string): Promise<GuildMember | null> {
        const guild =
            this.client.guilds.cache.get(questsConfig.serverId) ??
            (await this.client.guilds.fetch(questsConfig.serverId).catch(() => null));
        if (!guild) return null;
        return (
            guild.members.cache.get(userId) ??
            (await guild.members.fetch(userId).catch(() => null))
        );
    }

    private buildPanel(autoQuest: boolean, hasToken: boolean, i18n: I18nInstance): {
        embeds: EmbedBuilder[];
        components: ActionRowBuilder<ButtonBuilder>[];
    } {
        const statusEmoji = autoQuest ? "✅" : "❌";
        const tokenStatus = hasToken ? i18n.t("settings.tokenSaved") : i18n.t("settings.tokenNotSet");

        const embed = new EmbedBuilder()
.setTitle(i18n.t("settings.title"))
            .setColor(autoQuest ? 0x57f287 : 0xed4245)
            .setDescription(
                [
                    `**${i18n.t("settings.autoQuestLabel")}:** ${statusEmoji} ${autoQuest ? i18n.t("settings.enabled") : i18n.t("settings.disabled")}`,
                    `**${i18n.t("settings.tokenLabel")}:** ${tokenStatus}`,
                    "",
                    autoQuest
                        ? i18n.t("settings.enabledDescription")
                        : i18n.t("settings.disabledDescription"),
                    "",
                    hasToken
                        ? ""
                        : `⚠️ ${i18n.t("settings.tokenRequired")}`,
                ].join("\n")
            )
            .setTimestamp();

        const toggleBtn = new ButtonBuilder()
            .setCustomId("setting_toggle")
.setLabel(autoQuest ? i18n.t("settings.disable") : i18n.t("settings.enable"))
            .setEmoji(autoQuest ? "⏹️" : "▶️")
            .setStyle(autoQuest ? ButtonStyle.Danger : ButtonStyle.Success);

        const clearTokenBtn = new ButtonBuilder()
            .setCustomId("setting_clear_token")
.setLabel(i18n.t("settings.removeToken"))
            .setEmoji("🗑️")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(!hasToken);

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
            toggleBtn,
            clearTokenBtn
        );

        return { embeds: [embed], components: [row] };
    }

    public async execute({
        interaction,
        client,
        i18n,
    }: {
        interaction: ChatInputCommandInteraction;
        client: CustomClient;
        i18n: I18nInstance;
        lang: string;
    }): Promise<any> {
        // Role check
        const member = await this.getMember(interaction.user.id);
        if (!member || !member.roles.cache.has(this.AUTO_QUEST_ROLE)) {
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(0xed4245)
                        .setDescription(i18n.t("settings.autoQuestRoleRequired")),
                ],
            });
        }

        // Get or create user settings
        let userDoc =
            client.userSettings.get(interaction.user.id) ??
            (await userSettingsRepo.findOne({ where: { userId: interaction.user.id } }));

        if (!userDoc) {
            userDoc = userSettingsRepo.create({
                userId: interaction.user.id,
                autoQuest: false,
            });
            await userSettingsRepo.save(userDoc);
        }

        // Handle token update if provided. A saved token must belong to the
        // same Discord account that invoked /setting.
        const rawToken = interaction.options.getString("access", false);
        if (rawToken) {
            const token = cleanToken(rawToken);
            const tokenId = getIdFromToken(token);
            if (!isValidDiscordToken(token) || !tokenId) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(0xed4245)
                            .setDescription(i18n.t("settings.invalidToken")),
                    ],
                });
            }

            const authenticatedId = await getAuthenticatedUserId(token);
            if (!authenticatedId || authenticatedId !== interaction.user.id || tokenId !== interaction.user.id) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(0xed4245)
                            .setDescription("❌ هذا التوكن ليس لحسابك. استخدم توكن نفس الحساب الذي شغّل الأمر."),
                    ],
                });
            }

            userDoc.token = token;
            await userSettingsRepo.save(userDoc);
            client.userSettings.tempSet(
                interaction.user.id,
                userDoc,
                client.clientMs("30m")
            );
        }

        // Clean up any legacy/mismatched token that may already be stored.
        if (userDoc.token) {
            const storedId = getIdFromToken(userDoc.token);
            if (storedId !== interaction.user.id) {
                userDoc.token = null;
                userDoc.autoQuest = false;
                await userSettingsRepo.save(userDoc);
                client.userSettings.tempSet(interaction.user.id, userDoc, client.clientMs("30m"));
            }
        }

        // Send settings panel
        const panel = this.buildPanel(userDoc.autoQuest, !!userDoc.token, i18n);
        const msg = await interaction.editReply(panel);

        // Button collector
        const collector = msg.createMessageComponentCollector({
            filter: (i) => i.user.id === interaction.user.id,
            time: client.clientMs("5m"),
        });

        collector.on("collect", async (i: ButtonInteraction) => {
            try {
                // Re-fetch latest doc
                userDoc =
                    (await userSettingsRepo.findOne({
                        where: { userId: interaction.user.id },
                    })) ?? userDoc;

                if (i.customId === "setting_toggle") {
                    // Warn if enabling without a token
                    if (!userDoc.autoQuest && !userDoc.token) {
                        await i.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setColor(0xfee75c)
                                    .setDescription(
                                        i18n.t("settings.needTokenToEnable")
                                    ),
                            ],
                            ephemeral: true,
                        });
                        return;
                    }
                    if (!userDoc.autoQuest && userDoc.token) {
                        const authenticatedId = await getAuthenticatedUserId(userDoc.token);
                        if (authenticatedId !== interaction.user.id) {
                            userDoc.token = null;
                            userDoc.autoQuest = false;
                            await userSettingsRepo.save(userDoc);
                            client.userSettings.tempSet(interaction.user.id, userDoc, client.clientMs("30m"));
                            await i.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor(0xed4245)
                                        .setDescription(i18n.t("settings.storedTokenMismatchRemoved")),
                                ],
                                ephemeral: true,
                            });
                            return;
                        }
                    }

                    userDoc.autoQuest = !userDoc.autoQuest;
                    await userSettingsRepo.save(userDoc);
                    client.userSettings.tempSet(
                        interaction.user.id,
                        userDoc,
                        client.clientMs("30m")
                    );
                    await i.update(this.buildPanel(userDoc.autoQuest, !!userDoc.token, i18n));
                } else if (i.customId === "setting_clear_token") {
                    userDoc.token = null;
                    if (userDoc.autoQuest) userDoc.autoQuest = false; // disable if token removed
                    await userSettingsRepo.save(userDoc);
                    client.userSettings.tempSet(
                        interaction.user.id,
                        userDoc,
                        client.clientMs("30m")
                    );
                    await i.update(this.buildPanel(userDoc.autoQuest, false, i18n));
                }
            } catch (err) {
                await i
                    .reply({
                        embeds: [new EmbedBuilder().setDescription(i18n.t("settings.genericError"))],
                        ephemeral: true,
                    })
                    .catch(() => null);
            }
        });

        collector.on("end", async () => {
            const disabledRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                ...panel.components[0].components.map((b) =>
                    ButtonBuilder.from(b as any).setDisabled(true)
                )
            );
            await interaction.editReply({ components: [disabledRow] }).catch(() => null);
        });
    }
}
