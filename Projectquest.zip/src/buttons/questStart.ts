import { ButtonInteraction } from "discord.js";
import { buttonCommand } from "../lib/handler/buttons.js";
import { CustomClient } from "../core/customClient.js";
import { I18nInstance } from "../core/i18n.js";
import { userSettingsRepo, usersCache } from "../core/cache.js";
import { User } from "../lib/quest/User.js";
import { ChildManager } from "../core/ChildManager.js";
import questsConfig from "../config/questsConfig.js";
import { getIdFromToken, isValidDiscordToken } from "../utils/quest/tokenUtils.js";
import { Logger } from "../core/logger.js";
import { progressMessage, ChildMessage } from "../interface/ChildMessage.js";

/** Handles the "ابدأ المهمة" button on new quest notifications. */
export default class QuestStartButton extends buttonCommand {
    public name = "quest_start";
    public description = "Start a quest from its notification";
    public cooldown: number | string = "5s";
    public flags = ["noReply"] as any;

    public filter = (interaction: ButtonInteraction) =>
        interaction.isButton() && interaction.customId.toLowerCase().startsWith("quest_start:");

    public async execute({
        interaction,
        client,
        i18n,
    }: {
        interaction: ButtonInteraction;
        client: CustomClient;
        i18n: I18nInstance;
    }): Promise<any> {
        const questId = interaction.customId.slice("quest_start:".length);
        if (!questId) return interaction.reply({ content: "❌ تعذر تحديد المهمة.", ephemeral: true }).catch(() => null);

        const active = usersCache.get(interaction.user.id);
        if (active && active.started && !active.stoped) {
            return interaction.reply({ content: "⚠️ لديك مهمة قيد التنفيذ بالفعل.", ephemeral: true }).catch(() => null);
        }

        const settings = client.userSettings.get(interaction.user.id)
            ?? await userSettingsRepo.findOne({ where: { userId: interaction.user.id } });
        const token = settings?.token?.trim();
        if (!token || !isValidDiscordToken(token) || getIdFromToken(token) !== interaction.user.id) {
            return interaction.reply({
                content: "⚠️ احفظ بيانات الدخول أولًا من الإعدادات حتى تستطيع بدء المهمة من هذا الزر.",
                ephemeral: true,
            }).catch(() => null);
        }

        const member = await this.getMember(client, interaction.user.id);
        if (!member) return interaction.reply({ content: "❌ لا يمكن التحقق من حسابك في السيرفر.", ephemeral: true }).catch(() => null);

        const childProc = ChildManager.getLowestUsageChild();
        if (!childProc?.process || childProc.currentTasks >= questsConfig.questsPerChildProcess) {
            return interaction.reply({ content: "⚠️ لا يوجد عامل متاح حاليًا. جرّب بعد قليل.", ephemeral: true }).catch(() => null);
        }

        await interaction.deferReply({ ephemeral: true }).catch(() => null);

        try {
            const user = new User(token);
            const quests = await user.fetchQuests();
            const quest = quests?.get(questId);
            if (!quest) {
                user.destroy();
                return interaction.editReply(i18n.t("badge.questNoLongerAvailable")).catch(() => null);
            }
            if (!quest.isSupported()) {
                user.destroy();
                return interaction.editReply(i18n.t("badge.unsupportedQuest")).catch(() => null);
            }

            const enrolled = quest.progress.some(p => p.enrolled);
            if (!enrolled && !(await quest.enroll())) {
                user.destroy();
                return interaction.editReply(i18n.t("badge.enrollFailed")).catch(() => null);
            }
            if (!enrolled) await user.fetchQuests();

            const freshQuest = user.quests.get(questId) ?? quest;
            user.setQuest(freshQuest);
            user.setProcess(childProc.process);
            childProc.currentTasks++;
            await user.start();

            const listener = async (m: ChildMessage) => {
                if ("target" in m && typeof m.target === "string" && m.target !== user.id) return;
                if (m.type === "progress_update") {
                    const pm = m as progressMessage;
                    await user.updateProgress(pm.data.progress, pm.data.completed);
                    if (pm.data.completed && !user.completed) {
                        user.completed = true;
                        await user.sendCompleted();
                        user.stop();
                    }
                } else if (m.type === "kill" && !user.stoped) {
                    user.stop();
                }
            };
            user.on("message", listener);
            user.once("stopped", () => {
                user.off("message", listener);
                user.destroy();
            });

            Logger.info(`[QuestStart] User ${interaction.user.id} started quest ${questId} from notification.`);
            return interaction.editReply(`✅ ${i18n.t("badge.startedQuest", { quest: freshQuest.data.config.messages.quest_name })}`).catch(() => null);
        } catch (err) {
            Logger.error(`[QuestStart] Failed for ${interaction.user.id}:`, err);
            return interaction.editReply(i18n.t("badge.cannotStartQuest")).catch(() => null);
        }
    }

    private async getMember(client: CustomClient, userId: string) {
        const guild = client.guilds.cache.get(questsConfig.serverId)
            ?? await client.guilds.fetch(questsConfig.serverId).catch(() => null);
        return guild?.members.cache.get(userId)
            ?? await guild?.members.fetch(userId).catch(() => null);
    }
}
