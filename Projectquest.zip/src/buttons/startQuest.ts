import { ButtonInteraction, ButtonStyle, EmbedBuilder } from "discord.js";
import { buttonCommand } from "../lib/handler/buttons.js";
import { permissionList } from "../lib/handler/messageCommand.js";
import { slashCommandFlags } from "../lib/handler/slashCommand.js";
import { CustomClient } from "../core/customClient.js";
import { I18nInstance } from "../core/i18n.js";
import questsConfig from "../config/questsConfig.js";
import { userSettingsRepo, usersCache } from "../core/cache.js";
import { cleanToken, getAuthenticatedUserId, isValidDiscordToken } from "../utils/quest/tokenUtils.js";
import { User } from "../lib/quest/User.js";
import { ChildManager } from "../core/ChildManager.js";
import { ChildMessage, progressMessage } from "../interface/ChildMessage.js";

export default class startQuestButton extends buttonCommand {
    public name = "quest_start";
    public description = "Start a quest from a notification";
    public options = [];
    public cooldown: number | string = "10s";
    public bot_permissions: permissionList[] = [];
    public flags: slashCommandFlags[] = ["ephemeral", "noReply"];
    public filter = (interaction: ButtonInteraction) => interaction.customId.startsWith("quest_start:");

    public async execute({ interaction, client, i18n }: {
        interaction: ButtonInteraction;
        client: CustomClient;
        i18n: I18nInstance;
        lang: string;
    }): Promise<any> {
        const questId = interaction.customId.split(":").slice(1).join(":");
        if (!questId) return interaction.reply({ content: "❌ Quest not found.", ephemeral: true });

        const settings = await userSettingsRepo.findOne({ where: { userId: interaction.user.id } });
        const rawToken = settings?.token;
        if (!rawToken || !isValidDiscordToken(rawToken)) {
            return interaction.reply({ content: "⚠️ Save your token first with `/setting access:<token>`.", ephemeral: true });
        }

        const token = cleanToken(rawToken);
        const authenticatedId = await getAuthenticatedUserId(token);
        if (authenticatedId !== interaction.user.id) {
            if (settings) {
                settings.token = null;
                settings.autoQuest = false;
                await userSettingsRepo.save(settings);
            }
            return interaction.reply({ content: "⚠️ Your saved token changed or expired. Auto Quest was disabled. Please add your new token with `/setting access:<new token>`.", ephemeral: true });
        }

        const old = usersCache.get(interaction.user.id);
        if (old) await old.stop(true);

        const user = new User(token, undefined);
        user.setI18n(i18n);
        const quests = await user.fetchQuests();
        const quest = quests?.get(questId);
        if (!quest) return interaction.reply({ content: "❌ This quest is no longer available.", ephemeral: true });
        if (quest.isCompleted()) return interaction.reply({ content: "✅ You already completed this quest.", ephemeral: true });
        if (!quest.isSupported()) return interaction.reply({ content: "❌ This quest is not supported by the current solver.", ephemeral: true });

        if (!quest.progress.some(p => p.enrolled)) {
            const ok = await quest.enroll();
            if (!ok) return interaction.reply({ content: "❌ Could not enroll in the quest.", ephemeral: true });
            await user.fetchQuests();
        }

        const child = ChildManager.getLowestUsageChild();
        if (!child?.process || child.currentTasks >= questsConfig.questsPerChildProcess) {
            return interaction.reply({ content: "⚠️ Quest workers are busy right now. Try again shortly.", ephemeral: true });
        }

        user.setQuest(user.quests.get(questId) ?? quest);
        user.setProcess(child.process);
        child.currentTasks++;
        await user.start();

        const response = await interaction.reply({ ...user.genreate_message(), ephemeral: true, fetchReply: true });
        const listener = async (m: ChildMessage) => {
            if ((m as any).target && (m as any).target !== user.id) return;
            if (m.type === "progress_update") {
                const pm = m as progressMessage;
                await user.updateProgress(pm.data.progress, pm.data.completed);
                user.logs.push(`Progress ${pm.data.progress}/${pm.data.target} • ${Math.max(0, pm.data.target - pm.data.progress)} remaining`);
                await interaction.editReply({ ...user.genreate_message() }).catch(() => null);
                if (pm.data.completed && !user.completed) {
                    user.completed = true;
                    await user.sendCompleted();
                    await user.stop();
                }
            } else if (m.type === "kill" && !user.stoped) {
                await user.stop();
            } else if (m.type === "login_error" && !user.stoped) {
                await user.stop();
            }
        };
        user.on("message", listener);
        user.once("stopped", () => {
            user.off("message", listener);
            user.destroy();
        });

        void response;
    }
}
