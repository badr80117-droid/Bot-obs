import { Client, Collection } from "discord.js";
import { QuestConfig } from "../lib/questConfig.js";
import { loadQuests, sendToProcess } from "./tools.js";
import { ChildMessage } from "../interface/ChildMessage.js";
import { getIdFromToken } from "../utils/quest/tokenUtils.js";
import { ChildUser } from "./childUser.js";

const questsConfigs = new Collection<string, QuestConfig>();
export const clients = new Collection<string, ChildUser>();

// --- Error Handlers ---
function serializeError(err: unknown): string {
    if (!err) return "Unknown error";
    if (err instanceof Error) return err.message;
    try { return JSON.stringify(err); } catch { return String(err); }
}

process.on("uncaughtException", (err) => {
    console.error(`[Worker ${process.pid}] Uncaught Exception:`, err);
    try {
        process.send?.({
            type: "ERROR",
            error: `Uncaught Exception: ${serializeError(err)}`,
            stack: err instanceof Error ? err.stack : undefined,
        });
    } catch { /* ignore send errors */ }
    process.exit(1); // exit so ChildManager can respawn cleanly
});

process.on("unhandledRejection", (reason) => {
    console.error(`[Worker ${process.pid}] Unhandled Rejection:`, reason);
    try {
        process.send?.({
            type: "ERROR",
            error: `Unhandled Rejection: ${serializeError(reason)}`,
        });
    } catch { /* ignore send errors */ }
    process.exit(1);
});
export const addClient = (client: ChildUser) => {
    clients.set(client.id, client);
    sendToProcess({
        type: "process_update",
        count: clients.size

    })
}
export const removeClient = (client: ChildUser) => {
    if(!client?.id) return;
    if(!clients.has(client?.id)) return;
    clients.delete(client.id);
    client.destroy();
    sendToProcess({
        type: "process_update",
        count: clients.size,
    });
    // Hint V8 to collect freed memory after each task
    if (typeof (global as any).gc === "function") {
        (global as any).gc();
    }
}

// Async bootstrap
(async () => {
    await loadQuests(questsConfigs);
    console.log(`[Worker ${process.pid}] Quests loaded, ready for tasks.`);

    // Notify parent that worker is ready
    sendToProcess({
        type: "ready",
    })



    // Handle messages from parent
    process.on("message", async (msg: ChildMessage) => {
        try {
            if (!msg || !msg.type) return;

            switch (msg.type) {
                case "start": {
                    const { type, data } = msg;
                    const { token, method, questId, proxy, current, target } = data
                    const userId = getIdFromToken(data.token);
                    if (clients.has(userId)) {
                        console.warn(`[Worker ${process.pid}] User ${userId} is already being processed.`);
                        return;
                    }
                    const questConfig = questsConfigs.get(data.method);
                    if (!questConfig) {
                        console.error(`[Worker ${process.pid}] Quest ${data.method} not found.`);
                        sendToProcess?.({
                            type: "ERROR",
                            error: `Quest ${data.method} not found.`,
                        });
                        return;
                    }
                    const client = new ChildUser(token, proxy, questId, questConfig, current, target);
                    addClient(client);
                    client.start();
                    break;
                }
                case "kill": {
                    const { target } = msg;
                    if (!target) return
                    const user = clients.get(target);
                    if (user) {
                        user.stop();
                        removeClient(user);
                        console.log(`[Worker ${process.pid}] Stopped processing user ${target}.`);
                    } else {
                        console.warn(`[Worker ${process.pid}] No active process found for user ${target}.`);
                    }
                    break;
                }



            }
        } catch (err: any) {
            console.error(`[Worker ${process.pid}] Error while handling message:`, err);
            sendToProcess?.({
                type: "ERROR",
                error: err.message ?? String(err),
            });
        }
    });

    // Prevent the process from exiting when idle
    setInterval(() => { }, 1 << 30);

    // Memory watchdog: force GC when heap > 200MB to avoid OOM
    setInterval(() => {
        const { heapUsed, heapTotal } = process.memoryUsage();
        const usedMB = Math.round(heapUsed / 1024 / 1024);
        const totalMB = Math.round(heapTotal / 1024 / 1024);
        if (usedMB > 200 && typeof (global as any).gc === "function") {
            (global as any).gc();
            console.warn(`[Worker ${process.pid}] High heap: ${usedMB}/${totalMB}MB — GC triggered`);
        }
    }, 30_000); // check every 30s
})();
