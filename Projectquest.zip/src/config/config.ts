import { SupportedDatabaseTypes } from "../core/databaseConfig.js";
import { config as dotenvConfig } from "dotenv";
import { Config } from "../interface/config.js";
dotenvConfig();


export default {
    token: "",
    embedColor: "#06c2fb",
    defaultLanguage: "en",
    debugMode: true,
  //  allowedServers: ["1158846168957210635", "1399471603003428966"], // Example server IDs
    prefix: "!",
    developers: ["342019644170829825"],
    database: {
        type: SupportedDatabaseTypes.Sqlite,
        path: "./database.sqlite",
    },


} as Config