import { CustomClient } from "../core/customClient.js";

export default {
    notification: {
        token: "" ,// self accouont token (not bot)
        channel: "1301889128941748267",
        role: "1305828238332923947",
        dm: {
            enabled: true,
            dmRoles: ["1538223763831656480"], // Roles to receive DMs
        }

    },
    bypassLimit: ["1538223763831656480"], // Bypass quest limits
    durationQuests: [
        "WATCH_VIDEO",
        "PLAY_ON_DESKTOP",
        "STREAM_ON_DESKTOP",
        "PLAY_ACTIVITY",
        "WATCH_VIDEO_ON_MOBILE",
        "PLAY_ON_XBOX",
        "PLAY_ON_PLAYSTATION"
    ],

    image: {
        channelId: "1301889128941748267", // channel where bot will upload images
        guildId: "1301599438078214236", // server where bot will upload images
    },
    serverId: "1301599438078214236", // Server where the bot operates
    completedQuestsChannel: "1301889128941748267",
    voice: {
        channel: "1308186362738118810", // Voice channel for quests
        role: "1538223763831656480" // Role required for voice channel access
    },


    autoQuestRole: "1305381719259484201", // Role required to use auto-quest feature
    logStrings: [],
    childProcessCount: 1,
    questsPerChildProcess: 30,
    useProxy: true,
    proxyType: "http", // http, socks5, socks4
    buttons: [
        {
            url: "https://youtu.be/eJoa4obHhng", // Tutorial or guide
            emoji: (e:CustomClient) => e.getEmoji("youtube",false) ?? "▶️",
        }
    ],






    customRewardsImage: {
        "1298745361602449479": "https://i.ibb.co/rRNztwKq/reward.webp",
        "1287881739531976815": "https://i.ibb.co/vxTHNqsS/eff35518172b971fa47c521ca21c7576d3a245433a669a6765f63b744b7b733a.png"
    },
    customRewardsEmoji: {
        "1287881739531976815": "orbIcon",
        "1298745361602449479": "nitro_level_stone"
    },
    inviteUrl: "https://discord.gg/kZHHmhKE",
    joinMessage: `## انت مو داخل السيرفر
    - **عشان تستعمل البوت لازم تدخل السيرفر ب الحساب الي تبي تسوي فيه المهمة**
    - **ملاحظة البوت مجاني 100%**
    
    ## You are not in the server
    - **To use the bot, you need to join the server with the account you want to complete the task with.**
    - **Note: The bot is 100% free.**
    
    - ** https://discord.gg/39c2c3jVbN **`
}




